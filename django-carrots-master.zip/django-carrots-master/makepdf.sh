make latex
make latex  # yes, twice
cd build/latex
xelatex workshops.tex
xelatex workshops.tex  # twice, again

